package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.example.data.CoachPreferences
import com.example.ui.HomeScreen
import com.example.ui.PermissionScreen
import com.example.ui.theme.FFAssistantTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            FFAssistantTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val prefs = remember { CoachPreferences.getInstance(applicationContext) }
                    val isPermissionCompleted by prefs.isPermissionCompleted.collectAsState()

                    if (!isPermissionCompleted) {
                        PermissionScreen(
                            onPermissionsCompleted = {
                                prefs.setPermissionCompleted(true)
                            }
                        )
                    } else {
                        HomeScreen()
                    }
                }
            }
        }
    }
}
