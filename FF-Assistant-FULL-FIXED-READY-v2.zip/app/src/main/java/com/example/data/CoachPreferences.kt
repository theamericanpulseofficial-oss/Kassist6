package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class CoachPreferences private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("ff_assistant_prefs", Context.MODE_PRIVATE)

    private val _language = MutableStateFlow(prefs.getString(KEY_LANGUAGE, "Hinglish") ?: "Hinglish")
    val language: StateFlow<String> = _language.asStateFlow()

    private val _frequency = MutableStateFlow(prefs.getString(KEY_FREQUENCY, "Balanced") ?: "Balanced")
    val frequency: StateFlow<String> = _frequency.asStateFlow()

    private val _voiceEnabled = MutableStateFlow(prefs.getBoolean(KEY_VOICE_ENABLED, true))
    val voiceEnabled: StateFlow<Boolean> = _voiceEnabled.asStateFlow()

    private val _autoAdviceEnabled = MutableStateFlow(prefs.getBoolean(KEY_AUTO_ADVICE_ENABLED, true))
    val autoAdviceEnabled: StateFlow<Boolean> = _autoAdviceEnabled.asStateFlow()

    private val _isCoachOn = MutableStateFlow(prefs.getBoolean(KEY_COACH_ON, false))
    val isCoachOn: StateFlow<Boolean> = _isCoachOn.asStateFlow()

    private val _isMuted = MutableStateFlow(prefs.getBoolean(KEY_MUTED, false))
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _isPaused = MutableStateFlow(prefs.getBoolean(KEY_PAUSED, false))
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    private val _lastAdvice = MutableStateFlow(
        prefs.getString(KEY_LAST_ADVICE, "Coach ready. Start your match!") ?: "Coach ready. Start your match!"
    )
    val lastAdvice: StateFlow<String> = _lastAdvice.asStateFlow()

    private val _isPermissionCompleted = MutableStateFlow(prefs.getBoolean(KEY_PERMISSION_COMPLETED, false))
    val isPermissionCompleted: StateFlow<Boolean> = _isPermissionCompleted.asStateFlow()

    fun setLanguage(value: String) {
        prefs.edit().putString(KEY_LANGUAGE, value).apply()
        _language.value = value
    }

    fun setFrequency(value: String) {
        prefs.edit().putString(KEY_FREQUENCY, value).apply()
        _frequency.value = value
    }

    fun setVoiceEnabled(value: Boolean) {
        prefs.edit().putBoolean(KEY_VOICE_ENABLED, value).apply()
        _voiceEnabled.value = value
    }

    fun setAutoAdviceEnabled(value: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_ADVICE_ENABLED, value).apply()
        _autoAdviceEnabled.value = value
    }

    fun setCoachOn(value: Boolean) {
        prefs.edit().putBoolean(KEY_COACH_ON, value).apply()
        _isCoachOn.value = value
    }

    fun setMuted(value: Boolean) {
        prefs.edit().putBoolean(KEY_MUTED, value).apply()
        _isMuted.value = value
    }

    fun setPaused(value: Boolean) {
        prefs.edit().putBoolean(KEY_PAUSED, value).apply()
        _isPaused.value = value
    }

    fun setLastAdvice(value: String) {
        prefs.edit().putString(KEY_LAST_ADVICE, value).apply()
        _lastAdvice.value = value
    }

    fun setPermissionCompleted(value: Boolean) {
        prefs.edit().putBoolean(KEY_PERMISSION_COMPLETED, value).apply()
        _isPermissionCompleted.value = value
    }

    companion object {
        private const val KEY_LANGUAGE = "key_language"
        private const val KEY_FREQUENCY = "key_frequency"
        private const val KEY_VOICE_ENABLED = "key_voice_enabled"
        private const val KEY_AUTO_ADVICE_ENABLED = "key_auto_advice_enabled"
        private const val KEY_COACH_ON = "key_coach_on"
        private const val KEY_MUTED = "key_muted"
        private const val KEY_PAUSED = "key_paused"
        private const val KEY_LAST_ADVICE = "key_last_advice"
        private const val KEY_PERMISSION_COMPLETED = "key_permission_completed"

        @Volatile
        private var INSTANCE: CoachPreferences? = null

        fun getInstance(context: Context): CoachPreferences {
            return INSTANCE ?: synchronized(this) {
                val instance = CoachPreferences(context)
                INSTANCE = instance
                instance
            }
        }
    }
}
