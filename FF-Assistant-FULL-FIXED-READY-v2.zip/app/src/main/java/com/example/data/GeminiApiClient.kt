package com.example.data

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

object GeminiApiClient {
    // Testing build: API key supplied for this app.
    private const val API_KEY = "AQ.Ab8RN6K7z6oYX9ECV2nm5Ji6d6mCkrDx9jyTkOhl3XSMG1btFQ"
    private const val TAG = "GeminiApiClient"
    private const val API_ROOT = "https://generativelanguage.googleapis.com/v1beta"
    private const val DEFAULT_MODEL = "gemini-3.6-flash"

    @Volatile
    private var cachedModel: String? = null

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    data class ChatMessage(val role: String, val message: String)

    private fun validKey(): Boolean =
        API_KEY.isNotBlank() && API_KEY != "MY_GEMINI_API_KEY"

    /**
     * Finds a model actually exposed to this API key. This avoids a misleading
     * 404 when a particular model alias is unavailable for the key/project.
     */
    private fun resolveModel(apiKey: String, forceRefresh: Boolean = false): Result<String> {
        if (!forceRefresh) {
            cachedModel?.let { return Result.success(it) }
        }

        return try {
            val request = Request.Builder()
                .url("$API_ROOT/models")
                .header("x-goog-api-key", apiKey)
                .get()
                .build()

            val response = okHttpClient.newCall(request).execute()
            val body = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                Log.e(TAG, "Models API Error: ${response.code} $body")
                return Result.failure(
                    Exception("Gemini Models Error (${response.code}): ${shortError(body)}")
                )
            }

            val models = JSONObject(body).optJSONArray("models") ?: JSONArray()

            val available = mutableListOf<String>()
            for (i in 0 until models.length()) {
                val model = models.optJSONObject(i) ?: continue
                val name = model.optString("name")
                val methods = model.optJSONArray("supportedGenerationMethods") ?: JSONArray()

                var supportsGenerateContent = false
                for (j in 0 until methods.length()) {
                    if (methods.optString(j) == "generateContent") {
                        supportsGenerateContent = true
                        break
                    }
                }

                if (supportsGenerateContent && name.startsWith("models/")) {
                    available += name.removePrefix("models/")
                }
            }

            val preferred = listOf(
                DEFAULT_MODEL,
                "gemini-3.5-flash",
                "gemini-3.1-flash-lite",
                "gemini-2.5-flash-lite",
                "gemini-flash-latest",
                "gemini-2.5-flash"
            )

            val selected = preferred.firstOrNull { it in available }
                ?: available.firstOrNull { it.contains("gemini", ignoreCase = true) }

            if (selected == null) {
                return Result.failure(
                    Exception("No Gemini model available for this API key that supports generateContent.")
                )
            }

            cachedModel = selected
            Log.i(TAG, "Using Gemini model: $selected")
            Result.success(selected)
        } catch (e: Exception) {
            Log.e(TAG, "Model discovery failed", e)
            Result.failure(Exception("Gemini model discovery failed: ${e.message ?: "unknown error"}"))
        }
    }

    private fun shortError(body: String): String {
        return try {
            val json = JSONObject(body)
            val error = json.optJSONObject("error")
            val message = error?.optString("message").orEmpty()
            if (message.isNotBlank()) message.take(300) else body.take(300)
        } catch (_: Exception) {
            body.take(300)
        }
    }

    private fun generateRequest(
        apiKey: String,
        model: String,
        jsonBody: JSONObject
    ): Request {
        return Request.Builder()
            .url("$API_ROOT/models/$model:generateContent")
            .header("x-goog-api-key", apiKey)
            .header("Content-Type", "application/json")
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()
    }

    private fun extractText(responseBody: String): String {
        val json = JSONObject(responseBody)
        val candidates = json.optJSONArray("candidates") ?: return ""
        if (candidates.length() == 0) return ""

        val parts = candidates.optJSONObject(0)
            ?.optJSONObject("content")
            ?.optJSONArray("parts")
            ?: return ""

        val output = StringBuilder()
        for (i in 0 until parts.length()) {
            val text = parts.optJSONObject(i)?.optString("text").orEmpty()
            if (text.isNotBlank()) {
                if (output.isNotEmpty()) output.append("\n")
                output.append(text)
            }
        }
        return output.toString().trim()
    }

    /**
     * Generate text response for conversational queries with memory context.
     */
    suspend fun chatWithAi(
        userMessage: String,
        history: List<ChatMessage>,
        language: String
    ): Result<String> = withContext(Dispatchers.IO) {
        if (!validKey()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key is missing or invalid.")
            )
        }

        try {
            var modelResult = resolveModel(API_KEY)
            if (modelResult.isFailure) return@withContext modelResult

            var model = modelResult.getOrThrow()

            fun buildBody(): JSONObject {
                val systemPrompt = """
                    You are FF Assistant, a friendly, expert AI gaming coach and companion for mobile battle royale games.
                    Your response must be in $language language.
                    Keep responses concise, engaging, helpful, and natural for a mobile gamer.
                    If asked casual questions, jokes, or status like 'Tu kaisa hai?', respond naturally and humorously.
                    Do not give robotic or boilerplate replies.
                """.trimIndent()

                val rootJson = JSONObject()
                rootJson.put(
                    "systemInstruction",
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", systemPrompt))
                    )
                )

                val contents = JSONArray()
                history.takeLast(6).forEach { chat ->
                    contents.put(
                        JSONObject()
                            .put("role", if (chat.role == "user") "user" else "model")
                            .put(
                                "parts",
                                JSONArray().put(JSONObject().put("text", chat.message))
                            )
                    )
                }

                contents.put(
                    JSONObject()
                        .put("role", "user")
                        .put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", userMessage))
                        )
                )

                rootJson.put("contents", contents)
                rootJson.put(
                    "generationConfig",
                    JSONObject()
                        .put("maxOutputTokens", 250)
                )
                return rootJson
            }

            var response = okHttpClient.newCall(
                generateRequest(API_KEY, model, buildBody())
            ).execute()
            var responseBody = response.body?.string().orEmpty()

            // If the selected model is unavailable, refresh the model list once.
            if (response.code == 404) {
                Log.w(TAG, "Model $model returned 404; refreshing model list.")
                modelResult = resolveModel(API_KEY, forceRefresh = true)
                if (modelResult.isSuccess) {
                    model = modelResult.getOrThrow()
                    response = okHttpClient.newCall(
                        generateRequest(API_KEY, model, buildBody())
                    ).execute()
                    responseBody = response.body?.string().orEmpty()
                }
            }

            if (!response.isSuccessful) {
                Log.e(TAG, "Chat API Error: ${response.code} $responseBody")
                return@withContext Result.failure(
                    Exception("Gemini API Error (${response.code}): ${shortError(responseBody)}")
                )
            }

            val reply = extractText(responseBody)
            if (reply.isNotEmpty()) Result.success(reply)
            else Result.failure(Exception("Empty response from Gemini API"))
        } catch (e: Exception) {
            Log.e(TAG, "Chat error", e)
            Result.failure(e)
        }
    }

    suspend fun chatWithAiAndImage(
        userMessage: String,
        bitmap: Bitmap,
        history: List<ChatMessage>,
        language: String
    ): Result<String> = withContext(Dispatchers.IO) {
        if (!validKey()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key is missing or invalid.")
            )
        }

        try {
            val modelResult = resolveModel(API_KEY)
            if (modelResult.isFailure) return@withContext modelResult
            val model = modelResult.getOrThrow()

            val imageStream = ByteArrayOutputStream()
            val scaledBitmap = if (bitmap.width > 640 || bitmap.height > 640) {
                val scale = 640f / Math.max(bitmap.width, bitmap.height)
                Bitmap.createScaledBitmap(
                    bitmap,
                    (bitmap.width * scale).toInt(),
                    (bitmap.height * scale).toInt(),
                    true
                )
            } else bitmap

            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 70, imageStream)
            val base64Image = Base64.encodeToString(
                imageStream.toByteArray(),
                Base64.NO_WRAP
            )

            val rootJson = JSONObject()
            rootJson.put(
                "systemInstruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(
                        JSONObject().put(
                            "text",
                            """
                            You are FF Assistant, a friendly gaming coach and gaming buddy.
                            Answer in $language. The user is speaking while playing a mobile battle royale game.
                            Use the attached current gameplay screenshot when it contains useful visual information.
                            Answer the user's exact question naturally and concisely.
                            Never invent weapons, enemies, zones, positions, or statistics that are not visible.
                            If the screenshot is insufficient, clearly say that it is not visible instead of guessing.
                            For casual questions, respond naturally and humorously.
                            """.trimIndent()
                        )
                    )
                )
            )

            val contents = JSONArray()
            history.takeLast(6).forEach { chat ->
                contents.put(
                    JSONObject()
                        .put("role", if (chat.role == "user") "user" else "model")
                        .put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", chat.message))
                        )
                )
            }

            contents.put(
                JSONObject()
                    .put("role", "user")
                    .put(
                        "parts",
                        JSONArray()
                            .put(JSONObject().put("text", userMessage))
                            .put(
                                JSONObject().put(
                                    "inlineData",
                                    JSONObject()
                                        .put("mimeType", "image/jpeg")
                                        .put("data", base64Image)
                                )
                            )
                    )
            )

            rootJson.put("contents", contents)
            rootJson.put(
                "generationConfig",
                JSONObject().put("maxOutputTokens", 180)
            )

            val response = okHttpClient.newCall(
                generateRequest(API_KEY, model, rootJson)
            ).execute()
            val responseBody = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                Log.e(TAG, "Vision chat API Error: ${response.code} $responseBody")
                return@withContext Result.failure(
                    Exception("Gemini Vision Error (${response.code}): ${shortError(responseBody)}")
                )
            }

            val reply = extractText(responseBody)
            if (reply.isNotEmpty()) Result.success(reply)
            else Result.failure(Exception("Empty response from Gemini API"))
        } catch (e: Exception) {
            Log.e(TAG, "Voice vision chat error", e)
            Result.failure(e)
        }
    }

    suspend fun analyzeScreenFrame(
        bitmap: Bitmap,
        language: String
    ): Result<String?> = withContext(Dispatchers.IO) {
        if (!validKey()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key is not configured.")
            )
        }

        try {
            val modelResult = resolveModel(API_KEY)
            if (modelResult.isFailure) return@withContext modelResult
            val model = modelResult.getOrThrow()

            val output = ByteArrayOutputStream()
            val scaledBitmap = if (bitmap.width > 640 || bitmap.height > 640) {
                val scale = 640f / Math.max(bitmap.width, bitmap.height)
                Bitmap.createScaledBitmap(
                    bitmap,
                    (bitmap.width * scale).toInt(),
                    (bitmap.height * scale).toInt(),
                    true
                )
            } else bitmap

            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 70, output)
            val base64Image = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)

            val systemPrompt = """
                You are FF Assistant, an AI battle royale gaming coach inspecting a live gameplay screenshot.
                Look at the visual elements such as minimap, safe zone, player position, cover, fight indicators,
                weapons, HP level and visible loot.
                Language requirement: Output in $language language.

                RULES:
                1. Output ONLY 1 short, actionable, direct spoken advice sentence (10-15 words max).
                2. If there is NO urgent or meaningful advice, reply strictly with 'NO_ADVICE_NEEDED'.
                3. Never invent facts, exact enemy positions, or stats that are not clearly visible.
                4. Focus on zone rotation, cover/positioning, fight opportunities, low HP warning, or visible gear upgrades.
            """.trimIndent()

            val rootJson = JSONObject()
            rootJson.put(
                "systemInstruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", systemPrompt))
                )
            )

            val imagePart = JSONObject()
                .put("inlineData", JSONObject()
                    .put("mimeType", "image/jpeg")
                    .put("data", base64Image))

            rootJson.put(
                "contents",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put(
                            "parts",
                            JSONArray()
                                .put(
                                    JSONObject().put(
                                        "text",
                                        "Analyze this current mobile gameplay screen and provide short tactical advice if needed."
                                    )
                                )
                                .put(imagePart)
                        )
                )
            )

            rootJson.put(
                "generationConfig",
                JSONObject().put("maxOutputTokens", 100)
            )

            val response = okHttpClient.newCall(
                generateRequest(API_KEY, model, rootJson)
            ).execute()
            val responseBody = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                Log.e(TAG, "Vision API Error: ${response.code} $responseBody")
                return@withContext Result.failure(
                    Exception("Gemini Vision Error (${response.code}): ${shortError(responseBody)}")
                )
            }

            val advice = extractText(responseBody)
            if (advice.contains("NO_ADVICE_NEEDED", ignoreCase = true) || advice.isBlank()) {
                Result.success(null)
            } else {
                Result.success(advice)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Vision error", e)
            Result.failure(e)
        }
    }
}
