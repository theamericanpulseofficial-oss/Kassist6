package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.CoachPreferences
import com.example.data.GeminiApiClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import android.os.Bundle

class CoachForegroundService : Service(), TextToSpeech.OnInitListener {

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var analysisJob: Job? = null

    private lateinit var prefs: CoachPreferences
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var expandedView: View? = null
    private var windowParams: WindowManager.LayoutParams? = null

    private var screenWidth = 1080
    private var screenHeight = 2400
    private var screenDensity = 320

    private var lastSpokenAdvice: String = ""
    private var speechRecognizer: SpeechRecognizer? = null
    private var voiceConversationActive = false
    private var voiceProcessing = false
    private var isTtsSpeaking = false
    private var conversationHistory = mutableListOf<GeminiApiClient.ChatMessage>()

    override fun onCreate() {
        super.onCreate()
        prefs = CoachPreferences.getInstance(this)
        tts = TextToSpeech(this, this)

        val metrics = resources.displayMetrics
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi

        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START

        if (action == ACTION_STOP) {
            stopCoachService()
            return START_NOT_STICKY
        }

        val notification = createNotification("AI Gaming Coach is active in background")
        startForeground(NOTIFICATION_ID, notification)

        prefs.setCoachOn(true)

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

        if (resultCode != -1 && resultData != null) {
            setupMediaProjection(resultCode, resultData)
        }

        if (Settings.canDrawOverlays(this)) {
            showFloatingBubble()
        }

        startAnalysisLoop()
        // Start hands-free voice conversation automatically when the coach is activated.
        serviceScope.launch {
            delay(900)
            startVoiceConversation()
        }

        return START_STICKY
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mpManager.getMediaProjection(resultCode, data)

        val width = (screenWidth * 0.5).toInt()
        val height = (screenHeight * 0.5).toInt()

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "FF_Assistant_Screen",
            width,
            height,
            screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            null
        )
    }

    private fun startAnalysisLoop() {
        analysisJob?.cancel()
        analysisJob = serviceScope.launch(Dispatchers.Default) {
            while (isActive) {
                val isCoachOn = prefs.isCoachOn.value
                val isPaused = prefs.isPaused.value
                val autoAdvice = prefs.autoAdviceEnabled.value

                if (!isCoachOn) break

                if (!isPaused && autoAdvice) {
                    val bitmap = captureFrame()
                    if (bitmap != null) {
                        val language = prefs.language.value
                        val result = GeminiApiClient.analyzeScreenFrame(bitmap, language)
                        result.onSuccess { advice ->
                            if (advice != null && advice.isNotBlank() && advice != lastSpokenAdvice) {
                                lastSpokenAdvice = advice
                                withContext(Dispatchers.Main) {
                                    prefs.setLastAdvice(advice)
                                    updateFloatingAdviceText(advice)

                                    if (prefs.voiceEnabled.value && !prefs.isMuted.value) {
                                        speakAdvice(advice)
                                    }
                                }
                            }
                        }
                    }
                }

                val frequency = prefs.frequency.value
                val delayMs = when (frequency) {
                    "Low" -> 15000L
                    "High" -> 4000L
                    else -> 8000L // Balanced
                }
                delay(delayMs)
            }
        }
    }

    private fun captureFrame(): Bitmap? {
        val reader = imageReader ?: return null
        val image = reader.acquireLatestImage() ?: return null

        try {
            val planes = image.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val width = image.width
            val height = image.height

            val rowPadding = rowStride - pixelStride * width
            val bitmap = Bitmap.createBitmap(
                width + rowPadding / pixelStride,
                height,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)
            return Bitmap.createBitmap(bitmap, 0, 0, width, height)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to capture frame", e)
            return null
        } finally {
            image.close()
        }
    }

    private fun showFloatingBubble() {
        if (floatingView != null) return

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
        }
        windowParams = params

        val frameLayout = FrameLayout(this)
        val bubbleView = LayoutInflater.from(this).inflate(R.layout.overlay_floating_bubble, frameLayout, false)
        frameLayout.addView(bubbleView)
        floatingView = frameLayout

        // Dragging listener
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        bubbleView.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager?.updateViewLayout(floatingView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val diffX = Math.abs(event.rawX - initialTouchX)
                    val diffY = Math.abs(event.rawY - initialTouchY)
                    if (diffX < 10 && diffY < 10) {
                        toggleExpandedPanel()
                    }
                    true
                }
                else -> false
            }
        }

        windowManager?.addView(floatingView, params)
    }

    private fun toggleExpandedPanel() {
        if (expandedView != null) {
            windowManager?.removeView(expandedView)
            expandedView = null
            return
        }

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val expParams = WindowManager.LayoutParams(
            (screenWidth * 0.85).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        val panel = LayoutInflater.from(this).inflate(R.layout.overlay_expanded_panel, null)
        expandedView = panel

        val adviceText = panel.findViewById<TextView>(R.id.tv_expanded_advice)
        val btnTalk = panel.findViewById<View>(R.id.btn_expanded_talk)
        val btnMute = panel.findViewById<View>(R.id.btn_expanded_mute)
        val btnPause = panel.findViewById<View>(R.id.btn_expanded_pause)
        val btnStop = panel.findViewById<View>(R.id.btn_expanded_stop)
        val btnClose = panel.findViewById<View>(R.id.btn_expanded_close)

        adviceText.text = prefs.lastAdvice.value

        btnTalk.setOnClickListener {
            if (voiceConversationActive) {
                stopVoiceConversation()
            } else {
                startVoiceConversation()
            }
        }

        btnMute.setOnClickListener {
            val newMute = !prefs.isMuted.value
            prefs.setMuted(newMute)
            speakAdvice(if (newMute) "Voice muted" else "Voice unmuted")
        }

        btnPause.setOnClickListener {
            val newPause = !prefs.isPaused.value
            prefs.setPaused(newPause)
            speakAdvice(if (newPause) "Coach paused" else "Coach resumed")
        }

        btnStop.setOnClickListener {
            stopCoachService()
        }

        btnClose.setOnClickListener {
            windowManager?.removeView(expandedView)
            expandedView = null
        }

        windowManager?.addView(expandedView, expParams)
    }

    private fun updateFloatingAdviceText(advice: String) {
        expandedView?.findViewById<TextView>(R.id.tv_expanded_advice)?.text = advice
    }

    private fun startVoiceConversation() {
        if (voiceConversationActive) return
        if (!androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
            .equals(android.content.pm.PackageManager.PERMISSION_GRANTED)) {
            Log.w(TAG, "Microphone permission is not granted")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.w(TAG, "Speech recognition is not available on this device")
            return
        }

        if (speechRecognizer == null) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        updateFloatingAdviceText("Listening…")
                    }
                    override fun onBeginningOfSpeech() {
                        updateFloatingAdviceText("Listening…")
                    }
                    override fun onRmsChanged(rmsdB: Float) = Unit
                    override fun onBufferReceived(buffer: ByteArray?) = Unit
                    override fun onEndOfSpeech() {
                        updateFloatingAdviceText("Thinking…")
                    }
                    override fun onError(error: Int) {
                        if (voiceConversationActive && !voiceProcessing) {
                            serviceScope.launch {
                                delay(500)
                                startListeningOnce()
                            }
                        }
                    }
                    override fun onResults(results: Bundle?) {
                        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()?.trim().orEmpty()
                        if (text.isBlank()) {
                            if (voiceConversationActive) serviceScope.launch { delay(300); startListeningOnce() }
                            return
                        }
                        processVoiceQuestion(text)
                    }
                    override fun onPartialResults(partialResults: Bundle?) = Unit
                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                })
            }
        }

        voiceConversationActive = true
        startListeningOnce()
    }

    private fun startListeningOnce() {
        if (!voiceConversationActive || voiceProcessing || isTtsSpeaking) return
        val recognizer = speechRecognizer ?: return
        try {
            recognizer.cancel()
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, when (prefs.language.value) {
                    "Hindi" -> "hi-IN"
                    "English" -> "en-IN"
                    else -> "en-IN"
                })
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Could not start speech recognition", e)
        }
    }

    private fun stopVoiceConversation() {
        voiceConversationActive = false
        voiceProcessing = false
        speechRecognizer?.cancel()
        updateFloatingAdviceText(prefs.lastAdvice.value)
    }

    private fun processVoiceQuestion(question: String) {
        if (voiceProcessing) return
        voiceProcessing = true
        updateFloatingAdviceText("Thinking…")

        serviceScope.launch(Dispatchers.Default) {
            val bitmap = captureFrame()
            val language = prefs.language.value
            val result = if (bitmap != null) {
                GeminiApiClient.chatWithAiAndImage(question, bitmap, conversationHistory, language)
            } else {
                GeminiApiClient.chatWithAi(question, conversationHistory, language)
            }

            withContext(Dispatchers.Main) {
                voiceProcessing = false
                result.onSuccess { reply ->
                    conversationHistory.add(GeminiApiClient.ChatMessage("user", question))
                    conversationHistory.add(GeminiApiClient.ChatMessage("model", reply))
                    if (conversationHistory.size > 12) {
                        conversationHistory = conversationHistory.takeLast(12).toMutableList()
                    }
                    prefs.setLastAdvice(reply)
                    updateFloatingAdviceText(reply)
                    speakConversationReply(reply)
                }.onFailure { error ->
                    Log.e(TAG, "Voice conversation failed", error)
                    val message = "AI se reply nahi aa paya. Internet ya API connection check karo."
                    updateFloatingAdviceText(message)
                    speakConversationReply(message)
                }
            }
        }
    }

    private fun speakConversationReply(text: String) {
        if (!isTtsReady || tts == null || prefs.isMuted.value) {
            if (voiceConversationActive) serviceScope.launch { delay(250); startListeningOnce() }
            return
        }
        isTtsSpeaking = true
        tts?.stop()
        configureTtsLanguage()
        tts?.speak(cleanForSpeech(text), TextToSpeech.QUEUE_FLUSH, null, "FF_CONVERSATION")
    }

    private fun cleanForSpeech(text: String): String {
        return text.replace(Regex("[*_`#]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun speakAdvice(text: String) {
        if (!isTtsReady || tts == null || prefs.isMuted.value) return
        speechRecognizer?.cancel()
        isTtsSpeaking = true
        tts?.stop()
        configureTtsLanguage()
        tts?.speak(cleanForSpeech(text), TextToSpeech.QUEUE_FLUSH, null, "FF_ADVICE_ID")
    }

    private fun configureTtsLanguage() {
        val locale = when (prefs.language.value) {
            "Hindi" -> Locale("hi", "IN")
            "English" -> Locale("en", "IN")
            else -> Locale("en", "IN")
        }
        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale.US)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("en", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.US
            }
            tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { }
                override fun onDone(utteranceId: String?) {
                    serviceScope.launch(Dispatchers.Main) {
                        isTtsSpeaking = false
                        if ((utteranceId == "FF_CONVERSATION" || utteranceId == "FF_ADVICE_ID") && voiceConversationActive) {
                            delay(250)
                            startListeningOnce()
                        }
                    }
                }
                override fun onError(utteranceId: String?) {
                    serviceScope.launch(Dispatchers.Main) {
                        isTtsSpeaking = false
                        if ((utteranceId == "FF_CONVERSATION" || utteranceId == "FF_ADVICE_ID") && voiceConversationActive) {
                            delay(250)
                            startListeningOnce()
                        }
                    }
                }
            })
            isTtsReady = true
        }
    }

    private fun stopCoachService() {
        analysisJob?.cancel()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()

        if (floatingView != null) {
            windowManager?.removeView(floatingView)
            floatingView = null
        }
        if (expandedView != null) {
            windowManager?.removeView(expandedView)
            expandedView = null
        }

        prefs.setCoachOn(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopVoiceConversation()
        speechRecognizer?.destroy()
        speechRecognizer = null
        tts?.stop()
        tts?.shutdown()
        stopCoachService()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "FF Assistant Coach Channel",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Foreground Service for FF Assistant Gaming Coach"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(contentText: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, CoachForegroundService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent, PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FF Assistant - AI Coach Active")
            .setContentText(contentText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_media_pause, "Stop Coach", stopPendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun String.isNull_or_blank_custom(): Boolean {
        return this.trim().isEmpty()
    }

    companion object {
        const val CHANNEL_ID = "FF_ASSISTANT_COACH_CHANNEL"
        const val NOTIFICATION_ID = 8819

        const val ACTION_START = "com.example.service.ACTION_START"
        const val ACTION_STOP = "com.example.service.ACTION_STOP"

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        private const val TAG = "CoachForegroundService"
    }
}
