package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberNavy = Color(0xFF0B0E17)
val CyberDarkSurface = Color(0xFF141A29)
val CyberCardSurface = Color(0xFF1E2638)
val CyberBorder = Color(0xFF2C3852)

val NeonCyan = Color(0xFF00E5FF)
val NeonCyanGlow = Color(0x3300E5FF)
val NeonOrange = Color(0xFFFF6D00)
val NeonGreen = Color(0xFF00E676)
val NeonRed = Color(0xFFFF1744)

val TextPrimary = Color(0xFFF0F4FC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
